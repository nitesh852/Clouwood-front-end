import React from "react";

const Home = () => {
  return <div>Nitesh Bhati</div>;
};

export default Home;

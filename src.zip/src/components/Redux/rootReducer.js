// import { combineReducers } from "redux";
// import kitchenReducers from "./kitchenReducers";
// import bedroomReducers from "./bedroomReducers";

// const rootReducer = combineReducers({
//   kitchen: kitchenReducers,
//   bedroom: bedroomReducers,
// });

// export default rootReducer;
